#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <math.h>
#include <iostream>
#include "Filehandler/Matrix.h"
#include "Filehandler/Filehandler.h"

int main()
{
    sf::RenderWindow window(sf::VideoMode(800, 600), "SFML works!");
    sf::CircleShape player(20.0f);
	double playerX{ 10 };
	double playerY{ 10 };
	const short int playerSpeed{ 5 };

    FileHandler fh{"test"};
    int x{0};
    int y{0};

	//Off_screen rendering (unnecessary, double-buffering implemented in SFML)
    sf::RenderTexture off_screen;
    
    if(!off_screen.create(800,600))
      std::cerr << "Failed to load off_screen texture" << std::endl;
    
    sf::Sprite off_sprite(off_screen.getTexture());
    
	//Timestep algorithm (Semi-fixed)
	sf::Clock timer{};
	sf::Time t{};
	const int TIME_STEP{16}; //16 milliseconds
	int currentTime{};
	int frameTime{};
	int newTime{};


    while (window.isOpen())	{
		//Reset the time
		t = timer.restart();

        sf::Event event;

        while (window.pollEvent(event))	{
            if (event.type == sf::Event::Closed)
                window.close();
        }

		sf::Sprite test1{fh.getBlock(5)};
	
        //Run simulation as long as the time is smaller than dt (NEEDS FIXING)
		while (t.asMilliseconds() < TIME_STEP) {
			
			t = timer.getElapsedTime();
			
		}



		Matrix mat = fh.getArea(0, 0, 60, 60);
		int testing = mat.at(0, 0);

		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
			if(mat.at((int)round(playerX/32), (int)round(playerY / 32)) == 0)
				playerX++;
		}
		else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
			if (playerX > 0)
				playerX--;
		}
		else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) {
			playerY++;
		}
		else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) {
			if (playerY > 0)
				playerY--;
		}

		
		off_screen.clear();

		for(int i{x}; i < x+32; i++) {
		  for(int j{y}; j < y+32; j++) {
	    
			if(mat.at(i,j) != 0) {
			  test1.setPosition((i-x)*32, (j-y)*32);
			  test1.setTexture(fh.getBlock(mat.at(i,j)));
			  off_screen.draw(test1);
			}
		  }
		}

		//Player physics

		//Player collision

		player.setPosition(playerX, playerY);
		off_screen.draw(player);
		off_screen.display();
		off_sprite.setTexture(off_screen.getTexture());
	
		window.clear();
	
		window.draw(off_sprite);
	
		window.display();
    }

    return 0;
}
