#include "Map.h"
#include <thread>
using namespace std;

Map::Map(int x, int y) {
  
}

int* Map::getMap() {
  return mapLayer;
}
